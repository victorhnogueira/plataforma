@extends('layouts.loggedtemplate')

@section('content')
  <p>eaiiiiiii</p>
@endsection