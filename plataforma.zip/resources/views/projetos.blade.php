@extends('layouts.loggedtemplate')

@section('content')
  <p>esssa é a tela de projetos</p>
  <button class="btn btn-success">botao</button>
@endsection